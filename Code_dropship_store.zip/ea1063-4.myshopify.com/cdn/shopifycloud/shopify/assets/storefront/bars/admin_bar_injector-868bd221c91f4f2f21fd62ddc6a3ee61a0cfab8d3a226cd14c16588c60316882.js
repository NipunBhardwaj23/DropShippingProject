! function() {
    var t = function(t) {
            var e = {
                exports: {}
            };
            return t.call(e.exports, e, e.exports), e.exports
        },
        e = function() {
            function t(t, e) {
                for (var i = 0; i < e.length; i++) {
                    var o = e[i];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
                }
            }
            return function(e, i, o) {
                return i && t(e.prototype, i), o && t(e, o), e
            }
        }(),
        i = function(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
        },
        o = function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
        },
        n = function t(e, i, o) {
            null === e && (e = Function.prototype);
            var n = Object.getOwnPropertyDescriptor(e, i);
            if (void 0 === n) {
                var r = Object.getPrototypeOf(e);
                return null === r ? void 0 : t(r, i, o)
            }
            if ("value" in n) return n.value;
            var s = n.get;
            return void 0 !== s ? s.call(o) : void 0
        },
        r = function(t, e) {
            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !e || "object" != typeof e && "function" != typeof e ? t : e
        },
        s = function(t) {
            return t && t.__esModule ? t : {
                default: t
            }
        },
        a = t((function(t, o) {
            "use strict";

            function n(t) {
                !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1] ? window.open(t, "adminBarWindow") : window.location.assign(t)
            }

            function r() {
                window.location.reload()
            }
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.redirectToUrl = n, o.refreshPage = r;
            var s = function() {
                function t(e) {
                    var o = e.targetNode,
                        n = e.iframeRoot,
                        r = e.iframeSrc,
                        s = e.permanentDomain;
                    i(this, t), this.targetNode = o, this.iframeRoot = n, this.iframeSrc = r, this.permanentDomain = s
                }
                return e(t, [{
                    key: "createIframe",
                    value: function(t, e) {
                        this.iframe = document.createElement("iframe"), this.iframe.setAttribute("title", t), this.iframe.setAttribute("id", e), this.iframe.setAttribute("src", this.iframeSrc), this.iframe.setAttribute("sandbox", "allow-same-origin allow-scripts"), this.iframe.setAttribute("style", this.loadingStyles), this.targetNode.appendChild(this.iframe), this.target = this.iframe.contentWindow
                    }
                }], [{
                    key: "convertStylesObjectToString",
                    value: function(t) {
                        return Object.keys(t).map((function(e) {
                            return e + ": " + t[e] + ";"
                        })).join(" ")
                    }
                }, {
                    key: "returnObjectValues",
                    value: function(t) {
                        return Object.keys(t).map((function(e) {
                            return t[e]
                        }))
                    }
                }]), t
            }();
            o.default = s
        }));
    t((function(t, l) {
        "use strict";

        function u(t) {
            var e = t.countryCode,
                i = t.returnTo,
                o = document.createElement("form");
            o.action = "/localization", o.method = "POST", o.style.visibility = "hidden";
            var n = {
                _method: "PUT",
                return_to: i,
                country_code: e
            };
            Object.keys(n).forEach((function(t) {
                var e = n[t],
                    i = document.createElement("input");
                i.setAttribute("name", t), i.setAttribute("value", e), o.appendChild(i)
            })), document.body.append(o), o.submit()
        }

        function f() {
            var t = document.createElement("form");
            t.action = "/company_location_pricing_preview_destroy", t.method = "POST", t.style.visibility = "hidden", document.body.append(t), t.submit()
        }
        Object.defineProperty(l, "__esModule", {
            value: !0
        }), l.updateLocalization = u, l.companyLocationRemove = f;
        var d = function(t) {
            function s(t) {
                var e = t.targetNode,
                    o = t.iframeSrc,
                    n = t.permanentDomain;
                i(this, s);
                var a = r(this, (s.__proto__ || Object.getPrototypeOf(s)).call(this, {
                    targetNode: e,
                    iframeSrc: o,
                    permanentDomain: n
                }));
                return a.POST_MESSAGE_ACTIONS = {
                    TOGGLE_BAR: "toggle_bar",
                    SET_IFRAME_HEIGHT: "set_iframe_height",
                    REDIRECT_TO_URL: "redirect_to_url",
                    SET_INITIAL_STATE: "set_initial_state",
                    OPEN_POPOVER: "open_popover",
                    CLOSE_POPOVER: "close_popover",
                    TEMPLATE_EDITOR_REFRESH_PAGE: '{"key":"pageRefresh"}',
                    UPDATE_LOCALIZATION: "update_localization",
                    PREPARE_MODAL: "prepare_modal",
                    CLEANUP_MODAL: "cleanup_modal",
                    COMPANY_LOCATION_REMOVE: "company_location_remove"
                }, a.loadingStyles = s.convertStylesObjectToString({
                    position: "fixed",
                    border: "none"
                }), a.defaultStyles = s.convertStylesObjectToString({
                    position: "fixed",
                    bottom: 0,
                    left: 0,
                    "z-index": 2147483647,
                    width: "100%",
                    height: "auto",
                    border: "none"
                }), a.collapsedStyles = s.convertStylesObjectToString({
                    position: "fixed",
                    bottom: 0,
                    left: 0,
                    "z-index": 2147483647,
                    width: "80px",
                    height: "80px",
                    border: "none"
                }), a.popoverOpenStyles = s.convertStylesObjectToString({
                    position: "fixed",
                    bottom: 0,
                    left: 0,
                    "z-index": 2147483647,
                    width: "100%",
                    height: "100vh",
                    border: "none"
                }), a
            }
            return o(s, t), e(s, [{
                key: "init",
                value: function() {
                    this.postMessageBuffer = this.postMessageBuffer.bind(this), this.setInitialState = this.setInitialState.bind(this), n(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "createIframe", this).call(this, "Shopify Admin Bar", "admin-bar-iframe"), this.target = this.iframe.contentWindow, window.addEventListener("message", this.postMessageBuffer)
                }
            }, {
                key: "teardown",
                value: function() {
                    window.removeEventListener("message", this.postMessageBuffer), window.removeEventListener("DOMContentLoaded", this.setInitialState)
                }
            }, {
                key: "setInitialState",
                value: function() {
                    this.isCollapsed ? this.iframe.setAttribute("style", this.collapsedStyles) : this.iframe.setAttribute("style", this.defaultStyles)
                }
            }, {
                key: "postMessageBuffer",
                value: function(t) {
                    var e = t.data.action || t.data,
                        i = t.data,
                        o = i.height,
                        n = i.url,
                        r = i.isCollapsed,
                        a = i.newWindow,
                        l = i.id,
                        u = t.data.localeData,
                        f = t.origin;
                    !e || s.returnObjectValues(this.POST_MESSAGE_ACTIONS).indexOf(e) < 0 || f !== "https://" + this.permanentDomain || (e !== this.POST_MESSAGE_ACTIONS.SET_IFRAME_HEIGHT || o) && this.postMessageHandler(e, o, n, r, a, u, f, l)
                }
            }, {
                key: "postMessageHandler",
                value: function(t, e, i, o, n, r, s, l) {
                    t === this.POST_MESSAGE_ACTIONS.TOGGLE_BAR ? this.isCollapsed ? (this.isCollapsed = !1, this.iframe.setAttribute("style", this.defaultStyles), this.iframe.style.height = this.heightBeforeCollapse) : (this.isCollapsed = !0, this.heightBeforeCollapse = this.iframe.style.height, this.iframe.setAttribute("style", this.collapsedStyles)) : t === this.POST_MESSAGE_ACTIONS.SET_IFRAME_HEIGHT && null != e ? this.iframe.style.height = e + "px" : t === this.POST_MESSAGE_ACTIONS.REDIRECT_TO_URL && null != i ? (0, a.redirectToUrl)(i, n) : t === this.POST_MESSAGE_ACTIONS.OPEN_POPOVER ? this.iframe.setAttribute("style", this.popoverOpenStyles) : t === this.POST_MESSAGE_ACTIONS.CLOSE_POPOVER ? this.iframe.setAttribute("style", this.defaultStyles) : t === this.POST_MESSAGE_ACTIONS.SET_INITIAL_STATE ? o ? (this.isCollapsed = !0, this.iframe.setAttribute("style", this.collapsedStyles)) : (this.isCollapsed = !1, this.iframe.setAttribute("style", this.defaultStyles)) : t === this.POST_MESSAGE_ACTIONS.TEMPLATE_EDITOR_REFRESH_PAGE ? (0, a.refreshPage)() : t === this.POST_MESSAGE_ACTIONS.UPDATE_LOCALIZATION && null != r ? u(r) : t === this.POST_MESSAGE_ACTIONS.PREPARE_MODAL ? (this.iframe.setAttribute("style", this.popoverOpenStyles), this.sendPostMessage({
                        action: "modal_prepared",
                        id: l
                    }, s)) : t === this.POST_MESSAGE_ACTIONS.CLEANUP_MODAL ? (this.iframe.setAttribute("style", this.defaultStyles), this.sendPostMessage({
                        action: "modal_cleaned_up",
                        id: l
                    }, s)) : t === this.POST_MESSAGE_ACTIONS.COMPANY_LOCATION_REMOVE && f()
                }
            }, {
                key: "sendPostMessage",
                value: function(t, e) {
                    this.target.postMessage(t, e)
                }
            }]), s
        }(s(a).default);
        l.default = d, Shopify.AdminBarInjector = null != l.default ? l.default : l
    }))
}("undefined" != typeof global ? global : "undefined" != typeof window && window);